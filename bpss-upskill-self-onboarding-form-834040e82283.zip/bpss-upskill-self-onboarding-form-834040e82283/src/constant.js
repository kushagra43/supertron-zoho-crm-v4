export const BaseURL = 'https://api.betterplace.co.in' // Uat base url
export const ORGID = '44e40304-e367-447e-a9ee-0024bb03afa5' // Uat OrgId (Now using prod)
export const UserPolicy = '65fd3a2856dcf046bca55eeb'
// export const BaseURL = 'https://api.betterplace.co.in' // Prod base url
// export const ORGID = '44e40304-e367-447e-a9ee-0024bb03afa5' // Prod OrgId

export const playStoreLink = 'https://play.google.com/store/apps/details?id=com.attend_employee_app';
export const appStoreLink = 'https://apps.apple.com/in/app/gobetter-your-personal-hr/id6448507507';
export const webAppLink = 'https://ess.betterplace.co.in/';